#include <cstdlib>
#include <vector>
#include <string>
//#include <string.h>
extern std::vector < std::vector < std::string > > wherretf;
extern std::vector < std::string > solutionsLog;
extern std::string usedrotation, usedorientation;
//std::bool azzblockdone;
